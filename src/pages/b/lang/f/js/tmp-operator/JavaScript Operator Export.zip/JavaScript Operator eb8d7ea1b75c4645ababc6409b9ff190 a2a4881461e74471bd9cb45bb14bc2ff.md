# ... ** ...

Associativity: Right to Left
Precedence: 16
Type: Arithmetic

Exponentiation