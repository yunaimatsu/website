# ... << ...

Associativity: Left to Right
Description: Left Bitwise Shift
Precedence: 13
Type: Bitwise Operation