# ... ? ... : ...

Associativity: Right to Left
Description: Conditional
Precedence: 4
Type: Ternary

<aside>
⌨️

(Condition)`?`[Processing for True]`:`[Processing for False];

</aside>