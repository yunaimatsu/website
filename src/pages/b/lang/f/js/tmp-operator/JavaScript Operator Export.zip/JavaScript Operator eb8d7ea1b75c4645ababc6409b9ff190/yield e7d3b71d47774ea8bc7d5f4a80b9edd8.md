# yield* ...

Associativity: Right to Left
Description: yield*
Precedence: 2