# ... . ...

Associativity: Left to Right
Description: Member Access
Precedence: 20
Type: Data Type