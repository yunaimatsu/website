# new ...

Associativity: Right to Left
Description: new (without argument list)
Precedence: 19