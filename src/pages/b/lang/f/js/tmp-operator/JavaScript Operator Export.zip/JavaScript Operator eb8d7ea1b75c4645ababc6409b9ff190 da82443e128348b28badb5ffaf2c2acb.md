# ... * ...

Associativity: Left to Right
Precedence: 15
Type: Arithmetic

Multiplication