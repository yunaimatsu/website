# delete ...

Associativity: Right to Left
Description: Delete propety of object
Precedence: 17
Type: Unary