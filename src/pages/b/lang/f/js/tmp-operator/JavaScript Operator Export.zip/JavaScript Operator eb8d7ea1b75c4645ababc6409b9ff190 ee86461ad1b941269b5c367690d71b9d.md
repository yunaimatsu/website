# ... > ...

Associativity: Left to Right
Description: Greater Than
Precedence: 12
Type: Relational