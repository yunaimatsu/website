# await ...

Associativity: Right to Left
Description: await
Precedence: 17