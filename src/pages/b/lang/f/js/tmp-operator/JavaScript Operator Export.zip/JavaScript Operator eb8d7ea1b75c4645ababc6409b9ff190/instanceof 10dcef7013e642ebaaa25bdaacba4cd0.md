# ... instanceof ...

Associativity: Left to Right
Description: instanceof
Precedence: 12