# ... == ...

Associativity: Left to Right
Description: Equality
Precedence: 11
Type: Equality