# |...

Associativity: Left to Right
Description: Bitwise OR
Precedence: 8
Type: Bitwise Operation