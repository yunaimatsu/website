# ... >> ...

Associativity: Left to Right
Description: Right Bitwise Shift
Precedence: 13
Type: Bitwise Operation